package pkg22.pkg05.pkg2019.pkg3;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Random random = new Random();
        ArrayList<Integer> numeros = new ArrayList<Integer>();
        System.out.println("Llenando con repetir");
        for (int i = 0; i < 15; i++) {
            numeros.add(random.nextInt(20) + 1);
            System.out.println(numeros.get(i));
        }
        System.out.println("Llenando sin repetir");
        numeros.clear();
        for (int i = 0; i < 15; i++) {
            int num = random.nextInt(20) + 1;
            if (numeros.contains(num)) {
                i--;
            } else {
                numeros.add(num);
                System.out.println(num);
            }
        }
        seEncuentra(numeros);
        System.out.println("Tamaño antes de limpiar "+ numeros.size());
        numeros.clear();
        System.out.println("Tamaño despues de limpiar " + numeros.size());
    }
    public static int seEncuentra(ArrayList<Integer>numeros){
        Scanner intro = new Scanner(System.in);
        System.out.println("Ingrese un elemento para verificar si esta en el arreglo");
        int num = intro.nextInt();
        if (numeros.indexOf(num)!= -1){
            System.out.println("El numero esta en el indice " + numeros.indexOf(num));
        }else{
            System.out.println("El numero no esta ");
        }
        return numeros.indexOf(num);
    }
}

